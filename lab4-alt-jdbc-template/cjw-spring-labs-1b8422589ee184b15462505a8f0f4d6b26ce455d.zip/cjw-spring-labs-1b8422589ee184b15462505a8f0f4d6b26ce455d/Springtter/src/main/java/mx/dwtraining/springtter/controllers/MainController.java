package mx.dwtraining.springtter.controllers;

import mx.dwtraining.springtter.enums.ReactionTypeEnum;
import mx.dwtraining.springtter.interfaces.*;
import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.UUID;

@Controller
public class MainController {
    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ISpringtterRepository springtterRepository;

    @Autowired
    private IReactionRepository reactionRepository;

    @Autowired
    private IReactionTypeRepository reactionTypeRepository;

    @Autowired
    private IFriendshipRepository friendshipRepository;

    @GetMapping("/")
    public String index(Model model) {
        User user = StreamSupport.stream(userRepository.findAll().spliterator(), false)
            .findFirst()
            .orElse(null);
        Springtter newSpringtter = new Springtter();
        newSpringtter.setUserId(user.getId());
        List<SpringtterDTO> springtterDTOList = StreamSupport.stream(springtterRepository.findAllDTO(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollow(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        model.addAttribute("user", user);
        model.addAttribute("springtter", newSpringtter);
        model.addAttribute("springtterList", springtterDTOList);
        model.addAttribute("userList", userDTOList);
        return "layout/index";
    }

    @GetMapping("/sidebar")
    public String sidebar() {
        return "layout/sidebar";
    }

    @GetMapping("/homepage")
    public String homepage() {
        return "pages/homepage";
    }

    @GetMapping("/widgets")
    public String widgets() {
        return "layout/widgets";
    }

    @PostMapping("/add-springtter")
    public String addSpringtter(@Valid Springtter springtter, Errors errors, Model model, @RequestParam("file") MultipartFile image) {
        if (errors.hasErrors()) {
            User user = StreamSupport.stream(userRepository.findAll().spliterator(), false).findFirst().orElse(null);
            List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollow(user.getId()).spliterator(),
                false).collect(Collectors.toList());
            List<SpringtterDTO> springtterDTOList = StreamSupport.stream(springtterRepository.findAllDTO(user.getId()).spliterator(), false).collect(Collectors.toList());
            model.addAttribute("user", user);
            model.addAttribute("userList", userDTOList);
            model.addAttribute("springtter", springtter);
            model.addAttribute("springtterList", springtterDTOList);
            return "layout/index";
        }
        if (!springtter.getMessage().isEmpty() && !image.isEmpty()) {
            springtter.setImage(saveUploadedImage(image));
        }
        if (!springtter.getMessage().isEmpty()) {
            springtter.setDate(LocalDateTime.now());
            springtterRepository.add(springtter);
        }
        return "redirect:/";
    }

    private String saveUploadedImage(MultipartFile image) {
        String uniqueFileName = UUID.randomUUID().toString()+"_"+image.getOriginalFilename();
        Path rootPath = Paths.get("uploads").resolve(uniqueFileName);
        Path rootAbsolutePath = rootPath.toAbsolutePath();
        try {
            Files.copy(image.getInputStream(), rootAbsolutePath);
            return uniqueFileName;
        } catch (IOException e) {
            return "";
        }
    }

    @RequestMapping(value = "/edit-springtter/{id}/{message}")
    public String editSpringtter(@PathVariable long id, @PathVariable String message, Map<String, Object> model) {
        springtterRepository.edit(id, message);
        return "redirect:/";
    }

    @RequestMapping("/delete-springtter/{id}")
    public String deleteSpringtter(@PathVariable(value = "id") long id) {
        if (id > 0) {
            Springtter springtter = springtterRepository.findOne(id);
            if (springtter != null) {
                if (springtter.getImage() != "" &&
                    springtter.getImage() != null) {
                    if (deleteUploadedImage(springtter.getImage())) {
                        springtterRepository.delete(id);
                    }
                } else {
                    springtterRepository.delete(id);
                }
            }
        }
        return "redirect:/";
    }

    private boolean deleteUploadedImage(String image) {
        Path rootPath = Paths.get("uploads").resolve(image).toAbsolutePath();
        File file = rootPath.toFile();
        if (file.exists() && file.canRead()) {
            return file.delete();
        }
        return false;
    }

    @GetMapping("/springtter-comments/{id}")
    public String springtterComments(@PathVariable long id, Model model) {
        User user = StreamSupport.stream(userRepository.findAll().spliterator(), false).findFirst().orElse(null);
        ReactionType reactionType = reactionTypeRepository.findOne(ReactionTypeEnum.Comment.name());
        Reaction newReaction = new Reaction();
        newReaction.setSpringtterId(id);
        newReaction.setReactedUserId(user.getId());
        newReaction.setReactionTypeId(reactionType.getId());
        SpringtterDTO springtterDTO = springtterRepository.findOneDTO(id);
        List<ReactionDTO> reactionDTOList = StreamSupport.stream(reactionRepository.findAll(id, ReactionTypeEnum.Comment.name()).spliterator(), false)
            .collect(Collectors.toList());
        List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollow(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        model.addAttribute("page", "springtter-comments");
        model.addAttribute("user", user);
        model.addAttribute("newComment", newReaction);
        model.addAttribute("springtterDTO", springtterDTO);
        model.addAttribute("reactionDTOList", reactionDTOList);
        model.addAttribute("userList", userDTOList);
        return "layout/index";
    }

    @PostMapping("/add-comment")
    public String addComment(@Valid Reaction newComment, Errors errors, Model model) {
        if (!errors.hasErrors()) {
            newComment.setDate(LocalDateTime.now());
            reactionRepository.add(newComment);
        }
        return "redirect:/springtter-comments/" + newComment.getSpringtterId();
    }

    @GetMapping("/add-reaction/{springtterId}/{userId}/{reaction}")
    public String addReaction(@PathVariable long springtterId, @PathVariable long userId, @PathVariable String reaction) {
        ReactionType reactionType = reactionTypeRepository.findOne(reaction);
        Reaction reactionObject = new Reaction(springtterId, userId, reactionType.getId(), "", LocalDateTime.now());
        reactionRepository.add(reactionObject);
        return "redirect:/";
    }

    @GetMapping("add-friendship/{followerUserId}/{userId}")
    public String addFriendship(@PathVariable long userId, @PathVariable long followerUserId) {
        if (userId >= 0 && followerUserId >= 0 && userId != followerUserId) {
            friendshipRepository.add(new Friendship(userId, followerUserId));
        }
        return "redirect:/";
    }
}
