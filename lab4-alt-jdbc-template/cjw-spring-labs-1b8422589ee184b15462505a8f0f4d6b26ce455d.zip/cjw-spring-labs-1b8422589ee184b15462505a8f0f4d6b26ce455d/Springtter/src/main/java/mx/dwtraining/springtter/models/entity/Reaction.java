package mx.dwtraining.springtter.models.entity;

import java.time.LocalDateTime;

public class Reaction {
    private long id;
    private long springtterId;
    private long reactedUserId;
    private long reactionTypeId;
    private String comment;
    private LocalDateTime date;

    public Reaction() {
        this.id = 0;
        this.springtterId = 0;
        this.reactedUserId = 0;
        this.reactionTypeId = 0;
        this.comment = "";
        this.date = null;
    }

    public Reaction(long id, long springtterId, long reactedUserId, long reactionTypeId, String comment, LocalDateTime date) {
        this.id = id;
        this.springtterId = springtterId;
        this.reactedUserId = reactedUserId;
        this.reactionTypeId = reactionTypeId;
        this.comment = comment;
        this.date = date;
    }

    public Reaction(long springtterId, long reactedUserId, long reactionTypeId, String comment, LocalDateTime date) {
        this.springtterId = springtterId;
        this.reactedUserId = reactedUserId;
        this.reactionTypeId = reactionTypeId;
        this.comment = comment;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSpringtterId() {
        return springtterId;
    }

    public void setSpringtterId(long springtterId) {
        this.springtterId = springtterId;
    }

    public long getReactedUserId() {
        return reactedUserId;
    }

    public void setReactedUserId(long reactedUserId) {
        this.reactedUserId = reactedUserId;
    }

    public long getReactionTypeId() {
        return reactionTypeId;
    }

    public void setReactionTypeId(long reactionTypeId) {
        this.reactionTypeId = reactionTypeId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }
}
