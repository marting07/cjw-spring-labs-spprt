package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.interfaces.IFriendshipRepository;
import mx.dwtraining.springtter.models.entity.Friendship;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FriendshipRepository implements IFriendshipRepository {
    public static final String SQL_INSERT_FRIENDSHIP = "insert into friendships (user_id, follower_user_id) values (?, ?)";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public FriendshipRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate= jdbcTemplate;
    }

    @Override
    public Friendship add(Friendship friendship) {
        jdbcTemplate.update(
            SQL_INSERT_FRIENDSHIP,
            friendship.getUserId(),
            friendship.getFollowerUserId());
        return friendship;
    }
}
