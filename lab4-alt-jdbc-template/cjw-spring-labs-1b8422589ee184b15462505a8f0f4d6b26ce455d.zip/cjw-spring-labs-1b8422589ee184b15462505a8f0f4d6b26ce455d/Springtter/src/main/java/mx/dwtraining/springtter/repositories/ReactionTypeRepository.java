package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.interfaces.IReactionTypeRepository;
import mx.dwtraining.springtter.models.entity.ReactionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.*;

@Repository
public class ReactionTypeRepository implements IReactionTypeRepository {
    private static final String SQL_SELECT_REACTION_TYPE = "select id, reaction from reaction_types where reaction = ?";
    private static final String SQL_INSERT_REACTION_TYPE = "insert into reaction_types (reaction) values (?)";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public ReactionTypeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public ReactionType findOne(String reaction) {
        return jdbcTemplate.queryForObject(
            SQL_SELECT_REACTION_TYPE,
            this::mapRowToReactionType,
            reaction);
    }

    private ReactionType mapRowToReactionType(ResultSet resultSet, int rowNum) throws SQLException {
        return new ReactionType(
            Long.parseLong(resultSet.getString("id")),
            resultSet.getString("reaction"));
    }

    @Override
    public ReactionType add(String reaction) {
        jdbcTemplate.update(
            SQL_INSERT_REACTION_TYPE,
            reaction);
        return new ReactionType(reaction);
    }
}
