package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.interfaces.IUserRepository;
import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class UserRepository implements IUserRepository {
    private static final String SQL_SELECT_USERS = "select id, email, username, `password`, complete_name, profile_image, description from users";
    private static final String SQL_SELECT_USERS_TO_FOLLOW = "select id, username, complete_name, profile_image from users "+
        "where id <> ? and id not in (select friendships.user_id from friendships where friendships.follower_user_id = ?)";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Iterable<User> findAll() {
        return jdbcTemplate.query(
            SQL_SELECT_USERS,
            this::mapRowToUser);
    }

    private User mapRowToUser(ResultSet resultSet, int rowNum) throws SQLException {
        return new User(
            Long.parseLong(resultSet.getString("id")),
            resultSet.getString("email"),
            resultSet.getString("username"),
            "",
            resultSet.getString("complete_name"),
            resultSet.getString("profile_image"),
            resultSet.getString("description"));
    }

    @Override
    public Iterable<UserDTO> findAllToFollow(long id) {
        return jdbcTemplate.query(
            SQL_SELECT_USERS_TO_FOLLOW,
            this::mapRowToUserDTO,
            id,
            id);
    }

    private UserDTO mapRowToUserDTO(ResultSet resultSet, int rowNum) throws SQLException {
        return new UserDTO(
            Long.parseLong(resultSet.getString("id")),
            resultSet.getString("username"),
            resultSet.getString("complete_name"),
            resultSet.getString("profile_image"));
    }
}
