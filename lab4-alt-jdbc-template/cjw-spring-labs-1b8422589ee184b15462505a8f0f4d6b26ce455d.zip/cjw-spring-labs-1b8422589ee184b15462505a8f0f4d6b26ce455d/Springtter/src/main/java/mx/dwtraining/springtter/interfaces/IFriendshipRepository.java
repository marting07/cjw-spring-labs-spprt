package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.entity.Friendship;

public interface IFriendshipRepository {
    Friendship add(Friendship friendship);
}
