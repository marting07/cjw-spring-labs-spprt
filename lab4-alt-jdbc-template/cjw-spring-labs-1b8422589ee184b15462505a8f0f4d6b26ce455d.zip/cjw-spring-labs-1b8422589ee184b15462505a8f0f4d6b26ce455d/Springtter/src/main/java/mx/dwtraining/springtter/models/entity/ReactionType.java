package mx.dwtraining.springtter.models.entity;

public class ReactionType {
    private long id;
    private String reaction;

    public ReactionType(String reaction) {
        this.reaction = reaction;
    }

    public ReactionType(long id, String reaction) {
        this.id = id;
        this.reaction = reaction;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getReaction() {
        return reaction;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }
}
