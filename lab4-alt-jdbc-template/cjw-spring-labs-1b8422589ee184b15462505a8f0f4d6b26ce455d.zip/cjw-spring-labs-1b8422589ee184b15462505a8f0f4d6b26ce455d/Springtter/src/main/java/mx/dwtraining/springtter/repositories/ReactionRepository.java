package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.interfaces.IReactionRepository;
import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.entity.Reaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.*;

@Repository
public class ReactionRepository implements IReactionRepository {
    private static final String SQL_SELECT_REACTIONS = "select reactions.id, users.complete_name, users.username, users.profile_image, reactions.`date`, reactions.`comment` "+
        "from reactions inner join users on reactions.reacted_user_id = users.id inner join reaction_types on reactions.reaction_type_id = reaction_types.id "+
        "where reactions.springtter_id = ? and reaction_types.reaction = ?";
    private static final String SQL_INSERT_REACTION = "insert into reactions "+
        "(springtter_id, reacted_user_id, reaction_type_id, `comment`, `date`) "+
        "values (?, ?, ?, ?, ?)";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public ReactionRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Iterable<ReactionDTO> findAll(long springtterId, String reaction) {
        return jdbcTemplate.query(
            SQL_SELECT_REACTIONS,
            this::mapRowToReactionDTO,
            springtterId,
            reaction);
    }

    private ReactionDTO mapRowToReactionDTO(ResultSet resultSet, int rowNum) throws SQLException {
        return new ReactionDTO(
            Long.parseLong(resultSet.getString("id")),
            resultSet.getString("complete_name"),
            resultSet.getString("username"),
            resultSet.getString("profile_image"),
            resultSet.getTimestamp("date").toLocalDateTime(),
            resultSet.getString("comment"));
    }

    @Override
    public Reaction add(Reaction reaction) {
        jdbcTemplate.update(
            SQL_INSERT_REACTION,
            reaction.getSpringtterId(),
            reaction.getReactedUserId(),
            reaction.getReactionTypeId(),
            reaction.getComment(),
            Date.valueOf(reaction.getDate().toLocalDate()));
        return reaction;
    }
}
