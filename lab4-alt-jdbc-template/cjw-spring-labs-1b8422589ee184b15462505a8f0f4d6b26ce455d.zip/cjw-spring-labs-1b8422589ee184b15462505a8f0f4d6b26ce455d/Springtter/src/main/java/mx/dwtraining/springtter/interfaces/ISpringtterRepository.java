package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.entity.Springtter;

public interface ISpringtterRepository {
    Iterable<SpringtterDTO> findAllDTO(long id);
    SpringtterDTO findOneDTO(long id);
    Springtter findOne(long id);
    Springtter add(Springtter springtter);
    void edit(long id, String message);
    void delete(long id);
}
