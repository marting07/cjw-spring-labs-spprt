package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.interfaces.ISpringtterRepository;
import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.entity.Springtter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.*;

@Repository
public class SpringtterRepository implements ISpringtterRepository {
    private static final String SQL_SELECT_SPRINGTTERS_DTO = ""+
        "select springtters.id, springtters.user_id, users.complete_name, users.username, users.profile_image, "+
        "springtters.message, springtters.`date`, springtters.`image`, springtters.blocked, "+
        "(select count(*) from reactions inner join reaction_types on reactions.reaction_type_id = reaction_types.id "+
            "where reaction_types.reaction = 'Comment' and reactions.springtter_id = springtters.id) as number_of_comments, "+
        "(select count(*) from reactions inner join reaction_types on reactions.reaction_type_id = reaction_types.id "+
            "where reaction_types.reaction = 'Shared' and reactions.springtter_id = springtters.id) as number_of_shares, "+
        "(select count(*) from reactions inner join reaction_types on reactions.reaction_type_id = reaction_types.id "+
            "where reaction_types.reaction = 'Like' and reactions.springtter_id = springtters.id) as number_of_likes "+
        "from springtters inner join users on springtters.user_id = users.id "+
        "where users.id = ? or users.id in (select friendships.user_id from friendships where friendships.follower_user_id = ?) "+
        "order by springtters.`date` desc";
    private static final String SQL_SELECT_SPRINGTTER_DTO = SQL_SELECT_SPRINGTTERS_DTO +
        " where springtters.id = ?";
    private static final String SQL_SELECT_SPRINGTTER = "select * from springtters where springtters.id = ?";
    private static final String SQL_INSERT_SPRINGTTER = "insert into springtters (user_id, message, date, image, blocked) values (?, ?, ?, ?, ?)";
    private static final String SQL_UPDATE_SPRINGTTER = "update springtters set message = ? where id = ?";
    private static final String SQL_DELETE_SPRINGTTER = "delete from springtters where id = ?";
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public SpringtterRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Iterable<SpringtterDTO> findAllDTO(long userId) {
        return jdbcTemplate.query(
            SQL_SELECT_SPRINGTTERS_DTO,
            this::mapRowToSpringtterDTO,
            userId,
            userId);
    }

    @Override
    public SpringtterDTO findOneDTO(long id) {
        return jdbcTemplate.queryForObject(
            SQL_SELECT_SPRINGTTER_DTO,
            this::mapRowToSpringtterDTO,
            id);
    }

    private SpringtterDTO mapRowToSpringtterDTO(ResultSet resultSet, int rowNum) throws SQLException {
        return new SpringtterDTO(
            Long.parseLong(resultSet.getString("id")),
            Long.parseLong(resultSet.getString("user_id")),
            resultSet.getString("complete_name"),
            resultSet.getString("username"),
            resultSet.getString("profile_image"),
            resultSet.getString("message"),
            resultSet.getTimestamp("date").toLocalDateTime(),
            resultSet.getString("image"),
            Boolean.parseBoolean(resultSet.getString("blocked")),
            Long.parseLong(resultSet.getString("number_of_comments")),
            Long.parseLong(resultSet.getString("number_of_shares")),
            Long.parseLong(resultSet.getString("number_of_likes")));
    }

    @Override
    public Springtter findOne(long id) {
        return jdbcTemplate.queryForObject(
            SQL_SELECT_SPRINGTTER,
            this::mapRowToSpringtter,
            id);
    }

    private Springtter mapRowToSpringtter(ResultSet resultSet, int rowNum) throws SQLException {
        return new Springtter(
            Long.parseLong(resultSet.getString("id")),
            Long.parseLong(resultSet.getString("user_id")),
            resultSet.getString("message"),
            resultSet.getTimestamp("date").toLocalDateTime(),
            resultSet.getString("image"),
            Boolean.parseBoolean(resultSet.getString("blocked")));
    }

    @Override
    public Springtter add(Springtter springtter) {
        jdbcTemplate.update(
            SQL_INSERT_SPRINGTTER,
            springtter.getUserId(),
            springtter.getMessage(),
            Date.valueOf(springtter.getDate().toLocalDate()),
            springtter.getImage(),
            springtter.isBlocked());
        return springtter;
    }

    public void edit(long id, String message) {
        jdbcTemplate.update(
            SQL_UPDATE_SPRINGTTER,
            message,
            id);
    }

    @Override
    public void delete(long id) {
        jdbcTemplate.update(
            SQL_DELETE_SPRINGTTER,
            id);
    }
}
