package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.entity.ReactionType;

public interface IReactionTypeRepository {
    ReactionType findOne(String reaction);
    ReactionType add(String reaction);
}
