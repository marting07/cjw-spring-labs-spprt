package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.entity.Reaction;

public interface IReactionRepository {
    Iterable<ReactionDTO> findAll(long springtterId, String reaction);
    Reaction add(Reaction reaction);
}
