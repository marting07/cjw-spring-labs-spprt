insert into users(email, username, `password`, complete_name, profile_image, description)
    values('martin.ruiz@correo.com', '@Marting', '1234567890', 'Martin Ruiz', '50-User-Profile-Avatar-Icons-17.svg', 'Hola, soy Martin');
insert into users(email, username, `password`, complete_name, profile_image, description)
    values('juan.perez@correo.com', '@Juancho', '1938485', 'Juan Perez', '50-User-Profile-Avatar-Icons-50.svg', 'Hola, soy Juan');
insert into users(email, username, `password`, complete_name, profile_image, description)
    values('arturo.ponce@correo.com', '@R2d2', '84820493', 'Arturo Ponce', '50-User-Profile-Avatar-Icons-14.svg', 'Hola, soy Arturo');
