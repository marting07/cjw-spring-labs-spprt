package mx.dwtraining.springtter;

import mx.dwtraining.springtter.enums.ReactionTypeEnum;
import mx.dwtraining.springtter.models.entity.Springtter;
import mx.dwtraining.springtter.repositories.ReactionTypeRepository;
import mx.dwtraining.springtter.repositories.SpringtterRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;

@SpringBootApplication
public class SpringtterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringtterApplication.class, args);
    }

    private static void addReactionTypes(ReactionTypeRepository reactionTypeRepository) {
        reactionTypeRepository.add(ReactionTypeEnum.Like.name());
        reactionTypeRepository.add(ReactionTypeEnum.Shared.name());
        reactionTypeRepository.add(ReactionTypeEnum.Comment.name());
    }

    private static void addUsersSpringtters(SpringtterRepository springtterRepository) {
        springtterRepository.add(new Springtter(0, 2, "First springtter", LocalDateTime.now(), "", false));
        springtterRepository.add(new Springtter(0, 2, "Second springtter", LocalDateTime.now().minusDays(5), "", false));
        springtterRepository.add(new Springtter(0, 2, "Third springtter", LocalDateTime.now().minusDays(10), "", false));
        springtterRepository.add(new Springtter(0, 3, "Fourth springtter", LocalDateTime.now().minusDays(15), "", false));
        springtterRepository.add(new Springtter(0, 3, "Fifth springtter", LocalDateTime.now().minusDays(5), "", false));
    }

    @Bean
    public CommandLineRunner dataLoader(
        ReactionTypeRepository reactionTypeRepository,
        SpringtterRepository springtterRepository
    ) {
        return new CommandLineRunner() {
            @Override
            public void run(String... args) throws Exception {
                // Add Reaction Types
                addReactionTypes(reactionTypeRepository);
                // Add Springtters for the Users
                addUsersSpringtters(springtterRepository);
            }
        };
    }
}
