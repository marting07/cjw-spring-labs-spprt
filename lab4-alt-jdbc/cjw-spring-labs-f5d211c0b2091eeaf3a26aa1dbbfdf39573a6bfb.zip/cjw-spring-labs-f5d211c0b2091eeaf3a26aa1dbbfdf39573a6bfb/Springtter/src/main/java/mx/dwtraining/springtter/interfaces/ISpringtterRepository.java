package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.entity.Springtter;

public interface ISpringtterRepository {
    Iterable<SpringtterDTO> findAll(long id);
    SpringtterDTO findOne(long id);
    boolean add(Springtter springtter);
    boolean edit(long id, String message);
    void delete(long id);
}
