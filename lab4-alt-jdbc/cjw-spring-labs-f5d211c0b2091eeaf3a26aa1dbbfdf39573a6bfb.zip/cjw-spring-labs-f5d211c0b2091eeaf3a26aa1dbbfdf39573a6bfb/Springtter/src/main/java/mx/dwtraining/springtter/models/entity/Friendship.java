package mx.dwtraining.springtter.models.entity;

public class Friendship {
    private long id;
    private long userId;
    private long followerUserId;

    public Friendship(long userId, long followerUserId) {
        this.userId = userId;
        this.followerUserId = followerUserId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getFollowerUserId() {
        return followerUserId;
    }

    public void setFollowerUserId(long followerUserId) {
        this.followerUserId = followerUserId;
    }
}
