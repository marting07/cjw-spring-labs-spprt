package mx.dwtraining.springtter.interfaces;

import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.User;

public interface IUserRepository {
    Iterable<User> findAll();
    Iterable<UserDTO> findAllToFollow(long id);
    boolean add(User user);
    boolean edit(User user);
    void delete(long id);
}
