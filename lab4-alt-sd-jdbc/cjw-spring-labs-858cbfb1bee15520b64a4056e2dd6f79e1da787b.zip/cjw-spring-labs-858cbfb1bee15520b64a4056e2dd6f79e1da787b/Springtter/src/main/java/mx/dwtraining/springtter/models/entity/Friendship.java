package mx.dwtraining.springtter.models.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("FRIENDSHIPS")
public class Friendship {
    @Id
    private Long id;
    private Long userId;
    private Long followerUserId;

    public Friendship(Long userId, Long followerUserId) {
        this.userId = userId;
        this.followerUserId = followerUserId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getFollowerUserId() {
        return followerUserId;
    }

    public void setFollowerUserId(Long followerUserId) {
        this.followerUserId = followerUserId;
    }
}
