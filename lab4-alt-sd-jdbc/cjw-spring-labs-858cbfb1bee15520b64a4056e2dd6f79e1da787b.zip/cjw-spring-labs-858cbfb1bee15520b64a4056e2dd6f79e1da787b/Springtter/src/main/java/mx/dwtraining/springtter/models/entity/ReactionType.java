package mx.dwtraining.springtter.models.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("REACTION_TYPES")
public class ReactionType {
    @Id
    private Long id;
    private String reaction;

    public ReactionType() {
    }

    public ReactionType(String reaction) {
        this.reaction = reaction;
    }

    public ReactionType(Long id, String reaction) {
        this.id = id;
        this.reaction = reaction;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReaction() {
        return reaction;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }
}
