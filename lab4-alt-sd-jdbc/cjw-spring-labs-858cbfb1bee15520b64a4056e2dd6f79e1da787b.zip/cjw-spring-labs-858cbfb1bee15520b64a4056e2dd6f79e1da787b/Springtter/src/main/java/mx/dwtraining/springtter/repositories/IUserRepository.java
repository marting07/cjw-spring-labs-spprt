package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.User;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface IUserRepository extends CrudRepository<User, Long> {
    final String SQL_SELECT_USERS_TO_FOLLOW = "select Id, Username, Complete_Name, Profile_Image from USERS "+
        "where Id <> :id and Id not in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :id)";

    @Query(SQL_SELECT_USERS_TO_FOLLOW)
    Iterable<UserDTO> findAllToFollowById(@Param("id") long id);
}
