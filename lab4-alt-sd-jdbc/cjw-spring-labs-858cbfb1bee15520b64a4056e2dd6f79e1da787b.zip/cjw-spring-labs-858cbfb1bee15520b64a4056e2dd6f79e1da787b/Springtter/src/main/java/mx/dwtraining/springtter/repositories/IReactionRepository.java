package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.entity.Reaction;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface IReactionRepository extends CrudRepository<Reaction, Long> {
    final String SQL_SELECT_REACTIONS = "select REACTIONS.Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, USERS.Profile_Image as User_Profile_Image, REACTIONS.`Date`, REACTIONS.`Comment` "+
        "from REACTIONS inner join USERS on REACTIONS.Reacted_User_Id = USERS.Id inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTIONS.Springtter_Id = :springtterId and REACTION_TYPES.Reaction = :reaction";

    @Query(SQL_SELECT_REACTIONS)
    Iterable<ReactionDTO> findAll(@Param("springtterId") long springtterId, @Param("reaction") String reaction);
}
