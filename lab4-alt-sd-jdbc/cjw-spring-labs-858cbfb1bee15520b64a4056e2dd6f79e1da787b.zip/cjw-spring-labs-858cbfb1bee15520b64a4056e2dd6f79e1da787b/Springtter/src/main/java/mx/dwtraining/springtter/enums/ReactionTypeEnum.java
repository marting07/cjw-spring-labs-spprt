package mx.dwtraining.springtter.enums;

public enum ReactionTypeEnum {
    Like,
    Shared,
    Comment
}
