package mx.dwtraining.springtter.models.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

public class SpringtterDTO {
    @NotNull
    private long id;

    @NotNull
    private long userId;

    private String userCompleteName;

    private String username;

    private String userProfileImage;

    @Size(min = 0, max = 240)
    private String message;

    private LocalDateTime date;

    private String image;

    private boolean blocked;

    private long numberOfComments;

    private long numberOfShares;

    private long numberOfLikes;

    public SpringtterDTO(long id, long userId, String userCompleteName, String username, String userProfileImage,
                         String message, LocalDateTime date, String image, boolean blocked,
                         long numberOfComments, long numberOfShares, long numberOfLikes) {
        this.id = id;
        this.userId = userId;
        this.userCompleteName = userCompleteName;
        this.username = username;
        this.userProfileImage = userProfileImage;
        this.message = message;
        this.date = date;
        this.image = image;
        this.blocked = blocked;
        this.numberOfComments = numberOfComments;
        this.numberOfShares = numberOfShares;
        this.numberOfLikes = numberOfLikes;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUserCompleteName() {
        return userCompleteName;
    }

    public void setUserCompleteName(String userCompleteName) {
        this.userCompleteName = userCompleteName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserProfileImage() {
        return userProfileImage;
    }

    public void setUserProfileImage(String userProfileImage) {
        this.userProfileImage = userProfileImage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public long getNumberOfComments() {
        return numberOfComments;
    }

    public void setNumberOfComments(long numberOfComments) {
        this.numberOfComments = numberOfComments;
    }

    public long getNumberOfShares() {
        return numberOfShares;
    }

    public void setNumberOfShares(long numberOfShares) {
        this.numberOfShares = numberOfShares;
    }

    public long getNumberOfLikes() {
        return numberOfLikes;
    }

    public void setNumberOfLikes(long numberOfLikes) {
        this.numberOfLikes = numberOfLikes;
    }
}
