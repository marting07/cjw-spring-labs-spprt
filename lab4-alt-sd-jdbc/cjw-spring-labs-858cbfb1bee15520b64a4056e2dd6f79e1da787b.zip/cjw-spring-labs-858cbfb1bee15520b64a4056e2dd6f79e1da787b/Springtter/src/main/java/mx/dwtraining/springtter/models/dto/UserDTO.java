package mx.dwtraining.springtter.models.dto;

public class UserDTO {
    private long id;
    private String username;
    private String completeName;
    private String profileImage;

    public UserDTO() {
        id = 0;
        username = null;
        completeName = null;
        profileImage = null;
    }

    public UserDTO(long id, String username, String completeName, String profileImage) {
        this.id = id;
        this.username = username;
        this.completeName = completeName;
        this.profileImage = profileImage;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCompleteName() {
        return completeName;
    }

    public void setCompleteName(String completeName) {
        this.completeName = completeName;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }
}
