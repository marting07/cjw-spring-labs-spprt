package mx.dwtraining.springtter.models.dto;

import java.time.LocalDateTime;

public class ReactionDTO {
    private long id;
    private String userCompleteName;
    private String username;
    private String userProfileImage;
    private LocalDateTime date;
    private String comment;

    public ReactionDTO(long id, String userCompleteName, String username, String userProfileImage, LocalDateTime date, String comment) {
        this.id = id;
        this.userCompleteName = userCompleteName;
        this.username = username;
        this.userProfileImage = userProfileImage;
        this.date = date;
        this.comment = comment;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserCompleteName() {
        return userCompleteName;
    }

    public void setUserCompleteName(String userCompleteName) {
        this.userCompleteName = userCompleteName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserProfileImage() {
        return userProfileImage;
    }

    public void setUserProfileImage(String userProfileImage) {
        this.userProfileImage = userProfileImage;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
