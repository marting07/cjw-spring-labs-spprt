package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.entity.Springtter;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ISpringtterRepository extends CrudRepository<Springtter, Long> {
    final String SQL_SELECT_SPRINGTTERS_DTO = ""+
        "select SPRINGTTERS.Id, SPRINGTTERS.User_Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, "+
        "USERS.Profile_Image as User_Profile_Image, SPRINGTTERS.Message, SPRINGTTERS.`Date`, SPRINGTTERS.`Image`, SPRINGTTERS.Blocked, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Comment' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Comments, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Shared' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Shares, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Like' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Likes "+
        "from SPRINGTTERS inner join USERS on SPRINGTTERS.User_Id = USERS.Id "+
        "where USERS.Id = :id or USERS.Id in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :id) "+
        "order by SPRINGTTERS.`Date` desc";
    final String SQL_SELECT_SPRINGTTER_DTO = ""+
        "select SPRINGTTERS.Id, SPRINGTTERS.User_Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, "+
        "USERS.Profile_Image as User_Profile_Image, SPRINGTTERS.Message, SPRINGTTERS.`Date`, SPRINGTTERS.`Image`, SPRINGTTERS.Blocked, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Comment' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Comments, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Shared' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Shares, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Like' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Likes "+
        "from SPRINGTTERS inner join USERS on SPRINGTTERS.User_Id = USERS.Id "+
        "where USERS.Id = :userId or USERS.Id in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :userId) "+
        "and SPRINGTTERS.Id = :springtterId";
    final String SQL_UPDATE_SPRINGTTER = "update SPRINGTTERS set Message = :message where Id = :id";

    @Query(SQL_SELECT_SPRINGTTERS_DTO)
    Iterable<SpringtterDTO> findAllDTO(@Param("id") long id);

    @Query(SQL_SELECT_SPRINGTTER_DTO)
    SpringtterDTO findByIdDTO(@Param("springtterId") long springtterId, @Param("userId") long userId);

    @Modifying
    @Query(SQL_UPDATE_SPRINGTTER)
    void edit(@Param("id") long id, @Param("message") String message);
}
