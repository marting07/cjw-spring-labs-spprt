package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.entity.ReactionType;
import org.springframework.data.repository.CrudRepository;

public interface IReactionTypeRepository extends CrudRepository<ReactionType, Long> {
    ReactionType findByReaction(String reaction);
}
