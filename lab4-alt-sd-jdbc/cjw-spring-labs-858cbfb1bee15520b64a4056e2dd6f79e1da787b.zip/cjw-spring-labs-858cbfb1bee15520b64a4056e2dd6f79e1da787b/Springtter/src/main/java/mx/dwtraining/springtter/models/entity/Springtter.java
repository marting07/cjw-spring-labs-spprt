package mx.dwtraining.springtter.models.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Table("SPRINGTTERS")
public class Springtter {
    @Id
    private Long id;

    @NotNull
    private Long userId;

    @Size(min = 0, max = 240)
    private String message;

    private LocalDateTime date;

    private String image;

    private boolean blocked;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public Springtter() {
        this.userId = 0L;
        this.message = "";
        this.date = null;
        this.image = "";
        this.blocked = false;
    }

    public Springtter(Long id, Long userId, String message, LocalDateTime date, String image, boolean blocked) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.date = date;
        this.image = image;
        this.blocked = blocked;
    }

    public Springtter(Long userId, String message, LocalDateTime date, String image, boolean blocked) {
        this.userId = userId;
        this.message = message;
        this.date = date;
        this.image = image;
        this.blocked = blocked;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }
}
