create table if not exists SPRINGTTERS (
    Id bigint primary key auto_increment,
    User_Id bigint,
    Message varchar(240),
    `Date` datetime,
    `Image` varchar(120),
    Blocked boolean
);

create table if not exists USERS (
    Id bigint primary key auto_increment,
    Email varchar(240),
    Username varchar(50),
    `Password` varchar(50),
    Complete_Name varchar(120),
    Profile_Image varchar(120),
    Description varchar(512)
);

create table if not exists FRIENDSHIPS (
    Id bigint primary key auto_increment,
    User_Id bigint,
    Follower_User_Id bigint
);

create table if not exists REACTIONS (
    Id bigint primary key auto_increment,
    Springtter_Id bigint,
    Reacted_User_Id bigint,
    Reaction_Type_Id bigint,
    `Comment` varchar(240),
    `Date` datetime
);

create table if not exists REACTION_TYPES (
    Id bigint primary key auto_increment,
    Reaction varchar(128)
);