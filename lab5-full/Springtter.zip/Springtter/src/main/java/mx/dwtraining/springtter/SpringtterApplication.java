package mx.dwtraining.springtter;

import mx.dwtraining.springtter.enums.ReactionTypeEnum;
import mx.dwtraining.springtter.models.entity.ReactionType;
import mx.dwtraining.springtter.models.entity.User;
import mx.dwtraining.springtter.repositories.IReactionTypeRepository;
import mx.dwtraining.springtter.repositories.ISpringtterRepository;
import mx.dwtraining.springtter.models.entity.Springtter;
import mx.dwtraining.springtter.repositories.IUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.FileSystemUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

@SpringBootApplication
public class SpringtterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringtterApplication.class, args);
    }

    private static void startupUploadsResource() throws IOException {
        Path resource = Paths.get("uploads");
        FileSystemUtils.deleteRecursively(resource.toFile());
        Files.createDirectory(resource);
    }

    private static void addReactionTypes(IReactionTypeRepository reactionTypeRepository) {
        reactionTypeRepository.save(new ReactionType(ReactionTypeEnum.Like.name()));
        reactionTypeRepository.save(new ReactionType(ReactionTypeEnum.Shared.name()));
        reactionTypeRepository.save(new ReactionType(ReactionTypeEnum.Comment.name()));
    }

    private static void addUsers(IUserRepository userRepository, PasswordEncoder passwordEncoder) {
        userRepository.save(new User("martin.ruiz@correo.com", "@Marting", passwordEncoder.encode("1234567890"), "Martin Ruiz", "50-User-Profile-Avatar-Icons-17.svg", "Hola, soy Martin"));
        userRepository.save(new User("juan.perez@correo.com", "@Juancho", passwordEncoder.encode("1938485"), "Juan Perez", "50-User-Profile-Avatar-Icons-50.svg", "Hola, soy Juan"));
        userRepository.save(new User("arturo.ponce@correo.com", "@R2d2", passwordEncoder.encode("84820493"), "Arturo Ponce", "50-User-Profile-Avatar-Icons-14.svg", "Hola, soy Arturo"));
    }

    private static void addUsersSpringtters(ISpringtterRepository springtterRepository) {
        springtterRepository.save(new Springtter(2L, "First springtter", LocalDateTime.now(), "", false));
        springtterRepository.save(new Springtter(2L, "Second springtter", LocalDateTime.now().minusDays(5), "", false));
        springtterRepository.save(new Springtter(2L, "Third springtter", LocalDateTime.now().minusDays(10), "", false));
        springtterRepository.save(new Springtter(3L, "Fourth springtter", LocalDateTime.now().minusDays(15), "", false));
        springtterRepository.save(new Springtter(3L, "Fifth springtter", LocalDateTime.now().minusDays(5), "", false));
    }

    @Bean
    public CommandLineRunner dataLoader(
        IReactionTypeRepository reactionTypeRepository,
        IUserRepository userRepository,
        PasswordEncoder passwordEncoder,
        ISpringtterRepository springtterRepository
    ) {
        return new CommandLineRunner() {
            @Override
            public void run(String... args) throws Exception {
                startupUploadsResource();
                // Add Reaction Types
                addReactionTypes(reactionTypeRepository);
                // Add Users
                addUsers(userRepository, passwordEncoder);
                // Add Springtters for the Users
                addUsersSpringtters(springtterRepository);
            }
        };
    }
}
