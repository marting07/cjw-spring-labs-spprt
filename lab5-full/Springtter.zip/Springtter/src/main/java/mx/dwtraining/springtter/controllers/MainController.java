package mx.dwtraining.springtter.controllers;

import mx.dwtraining.springtter.enums.ReactionTypeEnum;
import mx.dwtraining.springtter.repositories.*;
import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.core.Authentication;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.UUID;

@Controller
public class MainController {
    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ISpringtterRepository springtterRepository;

    @Autowired
    private IReactionRepository reactionRepository;

    @Autowired
    private IReactionTypeRepository reactionTypeRepository;

    @Autowired
    private IFriendshipRepository friendshipRepository;

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @GetMapping("/")
    @Transactional
    public String index(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User)authentication.getPrincipal();
        List<Springtter> springtrs = StreamSupport.stream(springtterRepository.readSpringttersByUserId(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        List<Springtter> springttersSP = StreamSupport.stream(springtterRepository.getSpringttersFromUser(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        springtterRepository.updateMessage("This is my forced message", user.getId());
        Springtter newSpringtter = new Springtter();
        newSpringtter.setUserId(user.getId());
        List<SpringtterDTO> springtterDTOList = StreamSupport.stream(springtterRepository.findAllDTO(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollowById(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        model.addAttribute("user", user);
        model.addAttribute("springtter", newSpringtter);
        model.addAttribute("springtterList", springtterDTOList);
        model.addAttribute("userList", userDTOList);
        return "layout/index";
    }

    @GetMapping("/sidebar")
    public String sidebar() {
        return "layout/sidebar";
    }

    @GetMapping("/homepage")
    public String homepage() {
        return "pages/homepage";
    }

    @GetMapping("/widgets")
    public String widgets() {
        return "layout/widgets";
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @PostMapping("/add-springtter")
    public String addSpringtter(@Valid Springtter springtter, Errors errors, Model model, @RequestParam("file") MultipartFile image) {
        if (errors.hasErrors()) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            User user = (User)authentication.getPrincipal();
            List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollowById(user.getId()).spliterator(),
                false).collect(Collectors.toList());
            List<SpringtterDTO> springtterDTOList = StreamSupport.stream(springtterRepository.findAllDTO(user.getId()).spliterator(), false).collect(Collectors.toList());
            model.addAttribute("user", user);
            model.addAttribute("userList", userDTOList);
            model.addAttribute("springtter", springtter);
            model.addAttribute("springtterList", springtterDTOList);
            return "layout/index";
        }
        if (!springtter.getMessage().isEmpty() && !image.isEmpty()) {
            springtter.setImage(saveUploadedImage(image));
        }
        if (!springtter.getMessage().isEmpty()) {
            springtter.setDate(LocalDateTime.now());
            springtterRepository.save(springtter);
        }
        return "redirect:/";
    }

    private String saveUploadedImage(MultipartFile image) {
        String uniqueFileName = UUID.randomUUID().toString()+"_"+image.getOriginalFilename();
        Path rootPath = Paths.get("uploads").resolve(uniqueFileName);
        Path rootAbsolutePath = rootPath.toAbsolutePath();
        try {
            Files.copy(image.getInputStream(), rootAbsolutePath);
            return uniqueFileName;
        } catch (IOException e) {
            return "";
        }
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @RequestMapping(value = "/edit-springtter/{id}/{message}")
    public String editSpringtter(@PathVariable long id, @PathVariable String message, Map<String, Object> model) {
        springtterRepository.edit(id, message);
        return "redirect:/";
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @RequestMapping("/delete-springtter/{id}")
    public String deleteSpringtter(@PathVariable(value = "id") long id) {
        if (id > 0) {
            Springtter springtter = springtterRepository.findById(id).orElse(null);
            if (springtter != null) {
                if (springtter.getImage() != "" &&
                    springtter.getImage() != null) {
                    if (deleteUploadedImage(springtter.getImage())) {
                        springtterRepository.deleteById(id);
                    }
                } else {
                    springtterRepository.deleteById(id);
                }
            }
        }
        return "redirect:/";
    }

    private boolean deleteUploadedImage(String image) {
        Path rootPath = Paths.get("uploads").resolve(image).toAbsolutePath();
        File file = rootPath.toFile();
        if (file.exists() && file.canRead()) {
            return file.delete();
        }
        return false;
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @GetMapping("/springtter-comments/{id}")
    public String springtterComments(@PathVariable long id, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User)authentication.getPrincipal();
        ReactionType reactionType = reactionTypeRepository.findByReaction(ReactionTypeEnum.Comment.name());
        Reaction newReaction = new Reaction();
        newReaction.setSpringtterId(id);
        newReaction.setReactedUserId(user.getId());
        newReaction.setReactionTypeId(reactionType.getId());
        SpringtterDTO springtterDTO = springtterRepository.findByIdDTO(id, user.getId());
        List<ReactionDTO> reactionDTOList = StreamSupport.stream(reactionRepository.findAll(id, ReactionTypeEnum.Comment.name()).spliterator(), false)
            .collect(Collectors.toList());
        List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollowById(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        model.addAttribute("page", "springtter-comments");
        model.addAttribute("user", user);
        model.addAttribute("newComment", newReaction);
        model.addAttribute("springtterDTO", springtterDTO);
        model.addAttribute("reactionDTOList", reactionDTOList);
        model.addAttribute("userList", userDTOList);
        return "layout/index";
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @PostMapping("/add-comment")
    public String addComment(@Valid Reaction newComment, Errors errors, Model model) {
        if (!errors.hasErrors()) {
            newComment.setDate(LocalDateTime.now());
            reactionRepository.save(newComment);
        }
        return "redirect:/springtter-comments/" + newComment.getSpringtterId();
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @GetMapping("/add-reaction/{springtterId}/{userId}/{reaction}")
    public String addReaction(@PathVariable long springtterId, @PathVariable long userId, @PathVariable String reaction) {
        ReactionType reactionType = reactionTypeRepository.findByReaction(reaction);
        Reaction reactionObject = new Reaction(springtterId, userId, reactionType.getId(), "", LocalDateTime.now());
        reactionRepository.save(reactionObject);
        return "redirect:/";
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @GetMapping("add-friendship/{followerUserId}/{userId}")
    public String addFriendship(@PathVariable long userId, @PathVariable long followerUserId) {
        if (userId >= 0 && followerUserId >= 0 && userId != followerUserId) {
            friendshipRepository.save(new Friendship(userId, followerUserId));
        }
        return "redirect:/";
    }

    @Secured({"ROLE_USER", "ROLE_ADMIN"})
    @RequestMapping("/profile/{username}")
    public String profile(@PathVariable(value = "username") String username, Model model) {
        User user = userRepository.findByUsername(username);
        List<UserDTO> userDTOList = StreamSupport.stream(userRepository.findAllToFollowById(user.getId()).spliterator(),
            false).collect(Collectors.toList());
        List<SpringtterDTO> springtterDTOList = StreamSupport.stream(springtterRepository.findAllDTO(user.getId()).spliterator(),
            false)
            .filter(s -> s.getUserId() == user.getId())
            .collect(Collectors.toList());
        Iterable<Friendship> friendships = friendshipRepository.findAll();
        long following = StreamSupport.stream(friendships.spliterator(), false).filter(f -> f.getFollowerUserId() == user.getId()).count();
        long followers = StreamSupport.stream(friendships.spliterator(), false).filter(f -> f.getUserId() == user.getId()).count();
        model.addAttribute("user", user);
        model.addAttribute("page", "user-profile");
        model.addAttribute("userList", userDTOList);
        model.addAttribute("springtterList", springtterDTOList);
        model.addAttribute("following", following);
        model.addAttribute("followers", followers);
        return "layout/index";
    }
}
