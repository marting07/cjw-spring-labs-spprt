package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.ReactionDTO;
import mx.dwtraining.springtter.models.entity.Reaction;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface IReactionRepository extends CrudRepository<Reaction, Long> {
    @Query(nativeQuery = true)
    Iterable<ReactionDTO> findAll(@Param("springtterId") long springtterId, @Param("reaction") String reaction);
}
