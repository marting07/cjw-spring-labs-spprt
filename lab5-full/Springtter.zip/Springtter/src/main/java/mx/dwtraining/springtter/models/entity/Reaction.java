package mx.dwtraining.springtter.models.entity;

import mx.dwtraining.springtter.models.dto.ReactionDTO;

import javax.persistence.*;
import java.time.LocalDateTime;

@NamedNativeQuery(
    name = "Reaction.findAll",
    query = "select REACTIONS.Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, USERS.Profile_Image as User_Profile_Image, REACTIONS.`Date`, REACTIONS.`Comment` "+
        "from REACTIONS inner join USERS on REACTIONS.Reacted_User_Id = USERS.Id inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTIONS.Springtter_Id = :springtterId and REACTION_TYPES.Reaction = :reaction",
    resultSetMapping = "Mapping.ReactionDTO"
)
@SqlResultSetMapping(
    name = "Mapping.ReactionDTO",
    classes = @ConstructorResult(
        targetClass = ReactionDTO.class,
        columns = {
            @ColumnResult(name = "Id", type = Long.class),
            @ColumnResult(name = "User_Complete_Name", type = String.class),
            @ColumnResult(name = "Username", type = String.class),
            @ColumnResult(name = "User_Profile_Image", type = String.class),
            @ColumnResult(name = "Date", type = LocalDateTime.class),
            @ColumnResult(name = "Comment", type = String.class)
        }
    )
)

@Entity
@Table(name = "REACTIONS")
public class Reaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long springtterId;
    private Long reactedUserId;
    private Long reactionTypeId;
    private String comment;
    private LocalDateTime date;

    public Reaction() {
        this.springtterId = 0L;
        this.reactedUserId = 0L;
        this.reactionTypeId = 0L;
        this.comment = "";
        this.date = null;
    }

    public Reaction(Long id, Long springtterId, Long reactedUserId, Long reactionTypeId, String comment, LocalDateTime date) {
        this.id = id;
        this.springtterId = springtterId;
        this.reactedUserId = reactedUserId;
        this.reactionTypeId = reactionTypeId;
        this.comment = comment;
        this.date = date;
    }

    public Reaction(Long springtterId, Long reactedUserId, Long reactionTypeId, String comment, LocalDateTime date) {
        this.springtterId = springtterId;
        this.reactedUserId = reactedUserId;
        this.reactionTypeId = reactionTypeId;
        this.comment = comment;
        this.date = date;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSpringtterId() {
        return springtterId;
    }

    public void setSpringtterId(Long springtterId) {
        this.springtterId = springtterId;
    }

    public Long getReactedUserId() {
        return reactedUserId;
    }

    public void setReactedUserId(Long reactedUserId) {
        this.reactedUserId = reactedUserId;
    }

    public Long getReactionTypeId() {
        return reactionTypeId;
    }

    public void setReactionTypeId(Long reactionTypeId) {
        this.reactionTypeId = reactionTypeId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }
}
