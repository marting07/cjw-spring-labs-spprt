package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.entity.Friendship;
import org.springframework.data.repository.CrudRepository;

public interface IFriendshipRepository extends CrudRepository<Friendship, Long> {
}
