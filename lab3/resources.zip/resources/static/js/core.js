(function () {
    document.addEventListener("click", (event) => {
        const imageUploadSection = document.getElementById("image-upload");
        const imageDetach = document.getElementById("image-detach");
        if (imageUploadSection.contains(event.target)) {
            const imageFile = document.getElementById("image-file");
            imageFile.click();
        }
        if (imageDetach.contains(event.target) || imageDetach === event.target) {
            const imageFile = document.getElementById("image-file");
            const imageDisplay = document.getElementById("image-display");
            imageFile.value = "";
            imageDisplay.src = "";
            imageDetach.style.display = "none";
        }
    });

    const imageFile = document.getElementById("image-file");
    imageFile.onchange = () => {
        const [file] = imageFile.files;
        if (file) {
            const imageDisplay = document.getElementById("image-display");
            const imageDetach = document.getElementById("image-detach");
            const submitSpringtter = document.getElementById("submit-springtter");
            imageDisplay.src = URL.createObjectURL(file);
            imageDetach.style.display = "block";
            submitSpringtter.removeAttribute("disabled");
        }
    };

    document
        .getElementById("message-springtter")
        .addEventListener("input", (event) => {
            if (event.target.value !== "") {
                const submitSpringtter = document.getElementById("submit-springtter");
                submitSpringtter.removeAttribute("disabled");
            }
        });
})();