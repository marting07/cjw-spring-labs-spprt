(function () {
    let toggleFlag = false;
    let isRegisteredOnEditClickEvent = false;
    let isRegisteredOnCancelEditClickEvent = false;

    document.addEventListener("click", (event) => {
        const imageUploadSection = document.getElementById("image-upload");
        const imageDetach = document.getElementById("image-detach");
        const toggleEditDeletePopup = document.getElementById("toggle-edit-delete-popup");
        if (imageUploadSection.contains(event.target)) {
            const imageFile = document.getElementById("image-file");
            imageFile.click();
        }
        if (imageDetach.contains(event.target) || imageDetach === event.target) {
            const imageFile = document.getElementById("image-file");
            const imageDisplay = document.getElementById("image-display");
            imageFile.value = "";
            imageDisplay.src = "";
            imageDetach.style.display = "none";
        }
        if (toggleEditDeletePopup && toggleEditDeletePopup.contains(event.target) || toggleEditDeletePopup === event.target) {
            updateToggleEditDeletePopup();
            if (!(isRegisteredOnEditClickEvent || isRegisteredOnCancelEditClickEvent)) {
                captureClickOnEditSpringt();
                captureClickOnCancelEditSpringt();
            }
        }
    });

    const imageFile = document.getElementById("image-file");
    imageFile.onchange = () => {
        const [file] = imageFile.files;
        if (file) {
            const imageDisplay = document.getElementById("image-display");
            const imageDetach = document.getElementById("image-detach");
            const submitSpringtter = document.getElementById("submit-springtter");
            imageDisplay.src = URL.createObjectURL(file);
            imageDetach.style.display = "block";
            submitSpringtter.removeAttribute("disabled");
        }
    };

    document
        .getElementById("message-springtter")
        .addEventListener("input", (event) => {
            if (event.target.value !== "") {
                const submitSpringtter = document.getElementById("submit-springtter");
                submitSpringtter.removeAttribute("disabled");
            }
        });

    let updateToggleEditDeletePopup = () => {
        const editDeletePopup = document.getElementById("edit-delete-popup");
        if (editDeletePopup) {
            toggleFlag = !toggleFlag;
            if (toggleFlag) {
                editDeletePopup.style.display = "block";
            } else {
                editDeletePopup.style.display = "none";
            }
        }
    };

    let captureClickOnEditSpringt = () => {
        const editSpringt = document.getElementById("edit-springt");
        if (editSpringt) {
            editSpringt.addEventListener("click", (event) => {
                updateToggleEditDeletePopup();
                document.getElementById("springt-content").style.display = "none";
                document.getElementById("springt-editing-content").style.display = "block";
                document.getElementById("springt-actions").style.visibility = "hidden";
                document.getElementById("springt-edit-actions").style.visibility = "visible";
            });
            isRegisteredOnEditClickEvent = true;
        }
    }

    let captureClickOnCancelEditSpringt = () => {
        const cancelEditSpringt = document.getElementById("cancel-edit-springt");
        if (cancelEditSpringt) {
            cancelEditSpringt.addEventListener("click", (event) => {
                document.getElementById("springt-content").style.display = "block";
                document.getElementById("springt-editing-content").style.display = "none";
                document.getElementById("springt-actions").style.visibility = "visible";
                document.getElementById("springt-edit-actions").style.visibility = "hidden";
            });
            isRegisteredOnCancelEditClickEvent = true;
        }
    }
})();