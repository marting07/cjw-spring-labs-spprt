package mx.dwtraining.springtter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtterApplication.class, args);
	}

}
