package mx.dwtraining.springtter.controllers;

import mx.dwtraining.springtter.models.entity.Springtter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class MainController {
    private long userId = 1L;
    private String userCompleteName = "Martin Ruiz";
    private String username = "@Marting";
    private String userProfileImage = "50-User-Profile-Avatar-Icons-17.svg";
    private Long springtterIdCounter = 1L;
    private List<Springtter> springtterList = new ArrayList<>();

    @GetMapping("/")
    public String index(Model model) {
        Springtter newSpringtter = new Springtter();
        newSpringtter.setId(springtterIdCounter);
        springtterIdCounter++;
        newSpringtter.setUserId(userId);
        model.addAttribute("userCompleteName", userCompleteName);
        model.addAttribute("username", username);
        model.addAttribute("userProfileImage", userProfileImage);
        model.addAttribute("springtter", newSpringtter);
        model.addAttribute("springtterList", springtterList);
        return "layout/index";
    }

    // addSpringt
    @RequestMapping("/add-springtter")
    public String addSpringt(@Valid Springtter springtter, Errors errors, Model model, @RequestParam("file")MultipartFile image) {
        if (errors.hasErrors()) {
            model.addAttribute("userCompleteName", userCompleteName);
            model.addAttribute("username", username);
            model.addAttribute("userProfileImage", userProfileImage);
            model.addAttribute("springtter", springtter);
            model.addAttribute("springtterList", springtterList);
            return "layout/index";
        }
        Springtter newSpringtter = new Springtter();
        if (!springtter.getMessage().isEmpty()) {
            newSpringtter.setId(springtter.getId());
            newSpringtter.setMessage(springtter.getMessage());
            newSpringtter.setDate(LocalDateTime.now());
            newSpringtter.setBlocked(false);
        }
        if (!image.isEmpty() && saveUploadedImage(image)) {
            newSpringtter.setImage(image.getOriginalFilename());
        }
        springtterList.add(newSpringtter);
        return "redirect:/";
    }

    private boolean saveUploadedImage(MultipartFile image) {
        Path uploadDirectory = Paths.get("src/main/resources/static/uploads");
        String rooPath = uploadDirectory.toFile().getAbsolutePath();
        try {
            byte[] bytes = image.getBytes();
            Path fullPath = Paths.get(rooPath + "/" + image.getOriginalFilename());
            Files.write(fullPath, bytes);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    @RequestMapping(value = "/edit-springtter/{id}/{message}")
    public String editSpringt(@PathVariable long id, @PathVariable String message, Map<String, Object> model) {
        springtterList
                .stream()
                .forEach(s -> {
                    if (s.getId() == id) {
                        s.setMessage(message);
                    }
                });
        return "redirect:/";
    }

    @RequestMapping("/delete-springtter/{id}")
    public String deleteSpringt(@PathVariable(value = "id") long id) {
        if (id > 0) {
            springtterList.removeIf(s -> s.getId() == id);
        }
        return "redirect:/";
    }
}
