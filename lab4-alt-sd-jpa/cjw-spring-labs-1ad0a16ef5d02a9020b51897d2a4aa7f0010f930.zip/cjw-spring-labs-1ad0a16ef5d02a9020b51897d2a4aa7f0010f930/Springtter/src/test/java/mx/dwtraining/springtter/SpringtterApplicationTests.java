package mx.dwtraining.springtter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtterApplicationTests {

    @Test
    void contextLoads() {
    }

}
