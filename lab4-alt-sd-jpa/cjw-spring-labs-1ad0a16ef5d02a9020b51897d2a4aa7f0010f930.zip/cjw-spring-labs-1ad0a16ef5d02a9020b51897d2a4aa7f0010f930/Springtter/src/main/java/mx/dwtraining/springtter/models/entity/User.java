package mx.dwtraining.springtter.models.entity;

import mx.dwtraining.springtter.models.dto.UserDTO;

import javax.persistence.*;

@NamedNativeQuery(
    name = "User.findAllToFollowById",
    query = "select Id, Username, Complete_Name, Profile_Image from USERS "+
        "where Id <> :id and Id not in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :id)",
    resultSetMapping = "Mapping.UserDTO"
)
@SqlResultSetMapping(
    name = "Mapping.UserDTO",
    classes = @ConstructorResult(
        targetClass = UserDTO.class,
        columns = {
            @ColumnResult(name = "Id", type = Long.class),
            @ColumnResult(name = "Username", type = String.class),
            @ColumnResult(name = "Complete_Name", type = String.class),
            @ColumnResult(name = "Profile_Image", type = String.class)
        }
    )
)

@Entity
@Table(name = "USERS")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String username;
    private String password;
    private String completeName;
    private String profileImage;
    private String description;

    protected User() {
        this.id = 0L;
        this.email = "";
        this.username = "";
        this.password = "";
        this.completeName = "";
        this.profileImage = "";
        this.description = "";
    }

    public User(Long id, String email, String username, String password, String completeName, String profileImage, String description) {
        this.id = id;
        this.email = email;
        this.username = username;
        this.password = password;
        this.completeName = completeName;
        this.profileImage = profileImage;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCompleteName() {
        return completeName;
    }

    public void setCompleteName(String completeName) {
        this.completeName = completeName;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profile_image) {
        this.profileImage = profileImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
