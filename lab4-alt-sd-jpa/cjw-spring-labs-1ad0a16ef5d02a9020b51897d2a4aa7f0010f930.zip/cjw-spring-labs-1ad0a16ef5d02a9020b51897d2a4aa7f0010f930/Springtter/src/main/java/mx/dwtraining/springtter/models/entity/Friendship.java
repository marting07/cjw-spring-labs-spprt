package mx.dwtraining.springtter.models.entity;

import javax.persistence.*;

@Entity
@Table(name = "FRIENDSHIPS")
public class Friendship {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long followerUserId;

    protected Friendship() {
        id = 0L;
        userId = 0L;
        followerUserId = 0L;
    }

    public Friendship(Long userId, Long followerUserId) {
        this.userId = userId;
        this.followerUserId = followerUserId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getFollowerUserId() {
        return followerUserId;
    }

    public void setFollowerUserId(Long followerUserId) {
        this.followerUserId = followerUserId;
    }
}
