package mx.dwtraining.springtter.models.entity;

import mx.dwtraining.springtter.models.dto.SpringtterDTO;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@NamedNativeQuery(
    name = "Springtter.findAllDTO",
    query = ""+
        "select SPRINGTTERS.Id, SPRINGTTERS.User_Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, "+
        "USERS.Profile_Image as User_Profile_Image, SPRINGTTERS.Message, SPRINGTTERS.`Date`, SPRINGTTERS.`Image`, SPRINGTTERS.Blocked, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Comment' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Comments, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Shared' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Shares, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Like' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Likes "+
        "from SPRINGTTERS inner join USERS on SPRINGTTERS.User_Id = USERS.Id "+
        "where USERS.Id = :id or USERS.Id in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :id) "+
        "order by SPRINGTTERS.`Date` desc",
    resultSetMapping = "Mapping.SpringtterDTO"
)
@NamedNativeQuery(
    name = "Springtter.findByIdDTO",
    query = ""+
        "select SPRINGTTERS.Id, SPRINGTTERS.User_Id, USERS.Complete_Name as User_Complete_Name, USERS.Username, "+
        "USERS.Profile_Image as User_Profile_Image, SPRINGTTERS.Message, SPRINGTTERS.`Date`, SPRINGTTERS.`Image`, SPRINGTTERS.Blocked, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Comment' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Comments, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Shared' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Shares, "+
        "(select count(*) from REACTIONS inner join REACTION_TYPES on REACTIONS.Reaction_Type_Id = REACTION_TYPES.Id "+
        "where REACTION_TYPES.Reaction = 'Like' and REACTIONS.Springtter_Id = SPRINGTTERS.Id) as Number_Of_Likes "+
        "from SPRINGTTERS inner join USERS on SPRINGTTERS.User_Id = USERS.Id "+
        "where USERS.Id = :userId or USERS.Id in (select FRIENDSHIPS.User_Id from FRIENDSHIPS where FRIENDSHIPS.Follower_User_Id = :userId) "+
        "and SPRINGTTERS.Id = :springtterId",
    resultSetMapping = "Mapping.SpringtterDTO"
)
@SqlResultSetMapping(
    name = "Mapping.SpringtterDTO",
    classes = @ConstructorResult(
        targetClass = SpringtterDTO.class,
        columns = {
            @ColumnResult(name = "Id", type = Long.class),
            @ColumnResult(name = "User_Id", type = Long.class),
            @ColumnResult(name = "User_Complete_Name", type = String.class),
            @ColumnResult(name = "Username", type = String.class),
            @ColumnResult(name = "User_Profile_Image", type = String.class),
            @ColumnResult(name = "Message", type = String.class),
            @ColumnResult(name = "Date", type = LocalDateTime.class),
            @ColumnResult(name = "Image", type = String.class),
            @ColumnResult(name = "Blocked", type = Boolean.class),
            @ColumnResult(name = "Number_Of_Comments", type = long.class),
            @ColumnResult(name = "Number_Of_Shares", type = long.class),
            @ColumnResult(name = "Number_Of_Likes", type = long.class)
        }
    )
)

@Entity
@Table(name = "SPRINGTTERS")
public class Springtter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private Long userId;

    @Size(min = 0, max = 240)
    private String message;

    private LocalDateTime date;

    private String image;

    private boolean blocked;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public Springtter() {
        this.userId = 0L;
        this.message = "";
        this.date = null;
        this.image = "";
        this.blocked = false;
    }

    public Springtter(Long id, Long userId, String message, LocalDateTime date, String image, boolean blocked) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.date = date;
        this.image = image;
        this.blocked = blocked;
    }

    public Springtter(Long userId, String message, LocalDateTime date, String image, boolean blocked) {
        this.userId = userId;
        this.message = message;
        this.date = date;
        this.image = image;
        this.blocked = blocked;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }
}
