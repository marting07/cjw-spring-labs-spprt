package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.UserDTO;
import mx.dwtraining.springtter.models.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface IUserRepository extends CrudRepository<User, Long> {
    @Query(nativeQuery = true)
    Iterable<UserDTO> findAllToFollowById(long id);
}
