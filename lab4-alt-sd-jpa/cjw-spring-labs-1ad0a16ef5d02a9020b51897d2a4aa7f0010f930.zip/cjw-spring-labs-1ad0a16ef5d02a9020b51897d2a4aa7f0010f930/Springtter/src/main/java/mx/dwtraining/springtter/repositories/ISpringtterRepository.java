package mx.dwtraining.springtter.repositories;

import mx.dwtraining.springtter.models.dto.SpringtterDTO;
import mx.dwtraining.springtter.models.entity.Springtter;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ISpringtterRepository extends CrudRepository<Springtter, Long> {
    final String SQL_UPDATE_SPRINGTTER = "update SPRINGTTERS set Message = :message where Id = :id";

    @Query(nativeQuery = true)
    Iterable<SpringtterDTO> findAllDTO(@Param("id") long id);

    @Query(nativeQuery = true)
    SpringtterDTO findByIdDTO(@Param("springtterId") long springtterId, @Param("userId") long userId);

    @Transactional
    @Modifying
    @Query(value = SQL_UPDATE_SPRINGTTER, nativeQuery = true)
    void edit(@Param("id") long id, @Param("message") String message);
}
